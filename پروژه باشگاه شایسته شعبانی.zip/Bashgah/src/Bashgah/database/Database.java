package Bashgah.database;

import Bashgah.model.Member;
import java.util.ArrayList;

public class Database {

    public static ArrayList<Member> members = new ArrayList<>();

    public static void addMember(Member m) {
        members.add(m);
    }

    public static Member findMember(int id) {
        for (Member m : members)
            if (m.getId() == id)
                return m;
        return null;
    }
}
