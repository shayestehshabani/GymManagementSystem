package Bashgah.model;

public class Invoice {

    private double amount;
    private boolean paid;

    public Invoice(double amount) {
        this.amount = amount;
        this.paid = false;
    }

    public void pay() {
        paid = true;
    }

    public boolean isPaid() {
        return paid;
    }

    public double getAmount() {
        return amount;
    }
}
