package Bashgah.model;

import java.time.LocalDate;

public class Attendance {
    private LocalDate date;

    public Attendance() {
        this.date = LocalDate.now();
    }

    public LocalDate getDate() {
        return date;
    }
}
