package Bashgah.model;

import java.time.LocalDateTime;

public class Reservation {

    private String resource;
    private LocalDateTime time;

    public Reservation(String resource, LocalDateTime time) {
        this.resource = resource;
        this.time = time;
    }
}
