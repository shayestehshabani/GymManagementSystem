package Bashgah.model;

public class Membership {

    public enum MembershipType {
        MONTHLY, YEARLY, HOURLY
    }

    private MembershipType type;
    private double price;

    public Membership(MembershipType type, double price) {
        this.type = type;
        this.price = price;
    }

    public MembershipType getType() {
        return type;
    }

    public double getPrice() {
        return price;
    }
}
