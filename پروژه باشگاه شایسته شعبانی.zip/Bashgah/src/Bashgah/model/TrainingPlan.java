package Bashgah.model;

public class TrainingPlan {
    private String description;

    public TrainingPlan(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
