package Bashgah.model;

public class Coach extends Person {

    private double salary;

    public Coach(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }
}
