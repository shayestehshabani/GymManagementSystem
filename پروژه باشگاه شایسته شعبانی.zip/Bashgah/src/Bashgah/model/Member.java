package Bashgah.model;

import java.util.ArrayList;

public class Member extends Person {

    private static int counter = 0;

    private double paid;
    private double debt;
    private int score;

    private Membership membership;
    private TrainingPlan trainingPlan;

    private ArrayList<Course> courses = new ArrayList<>();
    private ArrayList<Attendance> attendances = new ArrayList<>();

    public Member(String name) {
        counter++;
        this.id = Integer.parseInt("404" + counter);
        this.name = name;
    }

    // اشتراک
    public void setMembership(Membership membership) {
        this.membership = membership;
        debt += membership.getPrice();
    }

    // افزودن دوره (چندتا می‌تونه باشه)
    public void addCourse(Course course) {
        courses.add(course);
        debt += course.getPrice();
        score += 20; // پاداش ثبت دوره
    }

    // پرداخت
    public void pay(double amount) {
        paid += amount;
        debt -= amount;
    }

    // حضور و غیاب
    public void addAttendance() {
        attendances.add(new Attendance());
        score += 10; // پاداش حضور
    }

    // برنامه تمرینی
    public void setTrainingPlan(TrainingPlan plan) {
        this.trainingPlan = plan;
    }

    private String coursesInfo() {
        if (courses.isEmpty()) return "None";
        String s = "";
        for (Course c : courses)
            s += c.getType() + " , ";
        return s;
    }

    @Override
    public String toString() {
        return
            "Name: " + name +
            "\nMember ID: " + id +
            "\nMembership: " +
                (membership == null ? "None" : membership.getType()) +
            "\nCourses: " + coursesInfo() +
            "\nTraining Plan: " +
                (trainingPlan == null ? "None" : trainingPlan.getDescription()) +
            "\nAttendance Count: " + attendances.size() +
            "\nScore: " + score +
            "\nPaid: " + paid +
            "\nDebt: " + debt;
    }
}
