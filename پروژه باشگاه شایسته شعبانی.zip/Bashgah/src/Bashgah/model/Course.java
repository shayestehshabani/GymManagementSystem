package Bashgah.model;

public class Course {

    public enum CourseType {
        FITNESS, YOGA, PILATES, CROSSFIT
    }

    private CourseType type;
    private double price;

    public Course(CourseType type, double price) {
        this.type = type;
        this.price = price;
    }

    public CourseType getType() {
        return type;
    }

    public double getPrice() {
        return price;
    }
}


