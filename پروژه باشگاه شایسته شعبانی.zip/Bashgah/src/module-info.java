/**
 * 
 */
/**
 * 
 */
module Bashgah {
	requires java.desktop;
}