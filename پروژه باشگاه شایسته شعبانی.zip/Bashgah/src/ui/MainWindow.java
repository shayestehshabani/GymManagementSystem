package ui;

import javax.swing.*;
import java.awt.event.*;

import Bashgah.model.*;
import Bashgah.database.Database;

public class MainWindow extends JFrame implements ActionListener {

    JButton registerBtn, searchBtn;

    public MainWindow() {

        setLayout(null);

        registerBtn = new JButton("Add Member");
        registerBtn.setBounds(30, 30, 220, 40);
        registerBtn.addActionListener(this);
        add(registerBtn);

        searchBtn = new JButton("Search Member");
        searchBtn.setBounds(30, 90, 220, 40);
        searchBtn.addActionListener(this);
        add(searchBtn);

        setTitle("Gym Management System");
        setSize(550, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // ثبت نام کامل
        if (e.getSource() == registerBtn) {

            String name = JOptionPane.showInputDialog("Member Name:");

            // اشتراک
            String[] memberships = {"MONTHLY", "YEARLY", "HOURLY"};
            String mType = (String) JOptionPane.showInputDialog(
                    this, "Select Membership", "Membership",
                    JOptionPane.PLAIN_MESSAGE, null,
                    memberships, memberships[0]);

            double mPrice = Double.parseDouble(
                    JOptionPane.showInputDialog("Membership Price:")
            );

            Member m = new Member(name);
            m.setMembership(new Membership(
            	    Membership.MembershipType.valueOf(mType), mPrice));

            // چند دوره
            String[] courses = {"FITNESS", "YOGA", "PILATES", "CROSSFIT"};

            int courseCount = Integer.parseInt(
                    JOptionPane.showInputDialog("How many courses?")
            );

            for (int i = 0; i < courseCount; i++) {
                String cType = (String) JOptionPane.showInputDialog(
                        this, "Select Course", "Course",
                        JOptionPane.PLAIN_MESSAGE, null,
                        courses, courses[0]);

                double cPrice = Double.parseDouble(
                        JOptionPane.showInputDialog("Course Price:")
                );

                m.addCourse(new Course(
                	    Course.CourseType.valueOf(cType), cPrice));

            }

            // برنامه تمرینی
            String plan = JOptionPane.showInputDialog("Training Plan:");
            m.setTrainingPlan(new TrainingPlan(plan));

            // حضور اولیه
            int attendanceCount = Integer.parseInt(
                    JOptionPane.showInputDialog("Initial attendance count:")
            );

            for (int i = 0; i < attendanceCount; i++)
                m.addAttendance();

            // پرداخت
            double paid = Double.parseDouble(
                    JOptionPane.showInputDialog("Paid Amount:")
            );
            m.pay(paid);

            Database.addMember(m);

            JOptionPane.showMessageDialog(this,
                    "Registered Successfully\nID: " + m.getId());
        }

        // جستجو
        if (e.getSource() == searchBtn) {
            int id = Integer.parseInt(
                    JOptionPane.showInputDialog("Member ID:")
            );

            Member m = Database.findMember(id);
            JOptionPane.showMessageDialog(this,
                    m == null ? "Member Not Found" : m.toString());
        }
    }
}

