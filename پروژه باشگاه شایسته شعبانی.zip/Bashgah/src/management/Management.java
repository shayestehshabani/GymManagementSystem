package management;

import ui.MainWindow;

public class Management {
    public static void main(String[] args) {
        new MainWindow();
    }
}
